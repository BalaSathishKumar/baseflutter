package com.base.flutter.base_flutter_provider_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
