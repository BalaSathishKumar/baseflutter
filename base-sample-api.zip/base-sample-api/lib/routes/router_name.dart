class RouterNames {
  static const String splash = '/';
  static const String login = '/login';
  static const String dashBoard = '/dashBoard';
  static const String home = '/home';
  static const String onBoarding = '/onBoarding';
  static const String otp = '/otp';
  static const String profile = '/profile';
}
