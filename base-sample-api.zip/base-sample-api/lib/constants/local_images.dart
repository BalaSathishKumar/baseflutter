// ignore_for_file: constant_identifier_names
class LocalSVGImages {
  LocalSVGImages._();
  static const String ic_brand_logo = 'assets/svg_icons/ic_flutter_logo.svg';
}

class LocalPNGImages {
  LocalPNGImages._();
  static const String connection_error = 'assets/png_icons/connection_error.png';
}
