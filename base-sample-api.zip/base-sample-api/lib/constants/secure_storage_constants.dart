class SecureStorageConstant {
  static const onBoarding = 'onBoardingStatus';
  static const authenticationUserType = 'authenticationUserType';
  static const isLoggedIn = 'isLoggedIn';
  static const token = 'token';
}
