class EndPointConstants {
  static const String homeScreenUrl = '/api/users?page=2';
  static const String testurl = '/api/users/2';
  static const String chatbotlist = '/api/users?page=2';
}
